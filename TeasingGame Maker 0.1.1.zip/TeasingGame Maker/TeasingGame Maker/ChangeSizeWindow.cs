﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeasingGame_Maker
{
    internal class ChangeSizeWindow
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public ChangeSizeWindow(int width, int height)
        {
            Width = width; Height = height;
        }
    }
}
