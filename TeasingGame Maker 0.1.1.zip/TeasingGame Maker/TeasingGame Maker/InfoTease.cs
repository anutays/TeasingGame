﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace TeasingGame_Maker
{
    internal class InfoTease
    {
        public string Name { get; set; }
        public string Author { get; set; }
        public Size SizeWindow { get; set; }
        public bool ShowInfo { get; set; }
        public string NameFolder { get; set; }
        public double Opacity { get; set; }
        public string IconWindow { get; set; }
        public InfoTease(string name, string author, Size sizeWindow, bool showInfo, string nameFolder, double opacity, string iconWindow)
        {
            Name = name; Author = author;
            SizeWindow = sizeWindow;
            ShowInfo = showInfo;
            NameFolder = nameFolder;
            Opacity = opacity;
            IconWindow = iconWindow;
        }
        public InfoTease()
        {
            Name = "Null"; Author = "Null"; SizeWindow = new Size();
            ShowInfo = false; NameFolder = "events"; IconWindow = "";
        }
    }
}
