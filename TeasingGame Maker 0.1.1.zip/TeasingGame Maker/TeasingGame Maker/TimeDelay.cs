﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeasingGame_Maker
{
    internal class TimeDelay
    {
        public int Interval { get; set; }
        public TimeDelay(int interval)
        {
            Interval = interval;
        }
        public static async Task Run(int interval)
        {
            await Task.Delay(interval * 1000);
        }
    }
}
