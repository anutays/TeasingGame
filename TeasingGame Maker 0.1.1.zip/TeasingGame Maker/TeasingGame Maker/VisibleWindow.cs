﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeasingGame_Maker
{
    internal class VisibleWindow
    {
        public bool Vis { get; set; }
        public VisibleWindow(bool vis)
        {
            Vis = vis;
        }
    }
}
