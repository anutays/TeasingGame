﻿using Microsoft.Win32;
using System;
using System.Drawing;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static TeasingGame_Maker.Wallpaper;

namespace TeasingGame_Maker
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
            IconBtnStart.Click += (events, e) =>
            {
                Microsoft.Win32.OpenFileDialog dialogICO = new Microsoft.Win32.OpenFileDialog();
                dialogICO.Filter = "Icon|*.ico";
                Nullable<bool> result = dialogICO.ShowDialog();
                if (result == true)
                {
                    IconBox.Text = dialogICO.FileName;
                }
            };
            btn1.Click += (events, e) =>
            {
                if (ProgramNameBox.Text.Length > 30 || ProgramNameBox.Text.Length == 0)
                {
                    System.Windows.MessageBox.Show("The program name must not exceed 30 characters and must contain at least one character.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                int temp = 0;
                if (!int.TryParse(SizeWindowWidthBox.Text, out temp) || temp < 500 || temp > 2000)
                {
                    System.Windows.MessageBox.Show("The window width should not be less than 500 and more than 2000 pixels.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                if (!int.TryParse(SizeWindowHeightBox.Text, out temp) || temp < 500 || temp > 2000)
                {
                    System.Windows.MessageBox.Show("The window height should not be less than 500 and more than 2000 pixels.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                if (FolderNameBox.Text.Length > 30 || FolderNameBox.Text.Length == 0)
                {
                    System.Windows.MessageBox.Show("The folder name must not exceed 30 characters and must contain at least one character.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                double tempD;
                if ((bool)WindowOpacityBox.IsChecked) tempD = 1;
                else tempD = 0;

                if (!Directory.Exists("Export"))
                {
                    Directory.CreateDirectory("Export");
                }
                if (Directory.Exists(@"Export\" + FolderNameBox.Text))
                {
                    Directory.Delete(@"Export\" + FolderNameBox.Text, true);
                }
                Directory.CreateDirectory(@"Export\" + FolderNameBox.Text);
                Directory.CreateDirectory(@"Export\" + FolderNameBox.Text + @"\" + FolderNameBox.Text);
                Directory.CreateDirectory(@"Export\" + FolderNameBox.Text + @"\" + FolderNameBox.Text + @"\" + "1");
                string icoTemp = "";
                if (File.Exists(IconBox.Text))
                {
                    icoTemp = FolderNameBox.Text + @"\" + "ico.ico";
                    File.Copy(IconBox.Text, @"Export\" + FolderNameBox.Text + @"\" + icoTemp);
                }
                InfoTease infoTease = new InfoTease(ProgramNameBox.Text, "Author",
                new System.Windows.Size(Convert.ToInt32(SizeWindowWidthBox.Text), Convert.ToInt32(SizeWindowHeightBox.Text)),
                false, FolderNameBox.Text, tempD, icoTemp);
                using (FileStream fs = new FileStream(@"Export\" + infoTease.NameFolder + @"\info.json", FileMode.Create))
                {
                    JsonSerializer.Serialize(fs, infoTease);
                }

                ListScenesBox.Items.Add("1");
                ListScenesBox.SelectedIndex = 0;
                AddSceneBtn.Click += (eventss, ee) =>
                {
                    ListScenesBox.Items.Add(ListScenesBox.Items.Count + 1);
                    Directory.CreateDirectory(@"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + (ListScenesBox.Items.Count));
                };
                ListScenesBox.SelectionChanged += (eventss, ee) =>
                {
                    ListEventsBox.Items.Clear();
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();
                    if (File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                        {
                            byte[] buffer = new byte[fstream.Length];
                            fstream.Read(buffer, 0, buffer.Length);
                            string evFile = Encoding.Default.GetString(buffer);
                            string[] evFileEvents = evFile.Split('\n');
                            for (int i = 0; i < evFileEvents.Length; i++)
                            {
                                ListEventsBox.Items.Add(evFileEvents[i]);
                            }
                        }
                    }
                };
                string[] eventsList = { "Caption", "MessageBox", "Visible Window", "Change wallpaper",
                "Open link", "Time delay", "Next scene", "Change size window"};

                foreach (string item in eventsList) EventsComboBox.Items.Add(item);

                EventsComboBox.SelectionChanged += (eventss, ee) =>
                {
                    if ((string)EventsComboBox.SelectedItem == "Caption") TBEvents.SelectedItem = CaptionTabItemEvents;
                    if ((string)EventsComboBox.SelectedItem == "MessageBox") TBEvents.SelectedItem = MessageTabItemEvents;
                    if ((string)EventsComboBox.SelectedItem == "Visible Window") TBEvents.SelectedItem = VisibleWindowTabItemEvents;
                    if ((string)EventsComboBox.SelectedItem == "Change wallpaper") TBEvents.SelectedItem = ChangeWallpaperTabItemEvents;
                    if ((string)EventsComboBox.SelectedItem == "Open link") TBEvents.SelectedItem = OpenLinkTabItemEvents;
                    if ((string)EventsComboBox.SelectedItem == "Time delay") TBEvents.SelectedItem = TimeDelayTabItemEvents;
                    if ((string)EventsComboBox.SelectedItem == "Next scene") TBEvents.SelectedItem = NextSceneTabItemEvents;
                    if ((string)EventsComboBox.SelectedItem == "Change size window") TBEvents.SelectedItem = ChangeSizeWindowTabItemEvents;
                };

                #region Caption

                FindPictureBtn.Click += (eventss, ee) =>
                {
                    Microsoft.Win32.OpenFileDialog dialogICO = new Microsoft.Win32.OpenFileDialog();
                    dialogICO.Filter = "Pictures|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tif";
                    Nullable<bool> result = dialogICO.ShowDialog();
                    if (result == true)
                    {
                        PicturePathBox.Text = dialogICO.FileName;
                    }
                };

                TextSideBox.Items.Add("Up"); TextSideBox.Items.Add("Down");
                TextSideBox.Items.Add("Right"); TextSideBox.Items.Add("Left");

                System.Drawing.Color backColorTemp = System.Drawing.Color.White;
                System.Drawing.Color fontColorTemp = System.Drawing.Color.Black;

                FindBackColorBtn.Click += (eventss, ee) =>
                {
                    ColorDialog colorDialog = new ColorDialog();
                    if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                        return;
                    BackColorPanel.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(colorDialog.Color.A,
                        colorDialog.Color.R, colorDialog.Color.G, colorDialog.Color.B));
                    backColorTemp = colorDialog.Color;
                };
                FindFontColorBtn.Click += (eventss, ee) =>
                {
                    ColorDialog colorDialog = new ColorDialog();
                    if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                        return;
                    FontColorPanel.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(colorDialog.Color.A,
                        colorDialog.Color.R, colorDialog.Color.G, colorDialog.Color.B));
                    fontColorTemp = colorDialog.Color;
                };
                FindFontBtn.Click += (eventss, ee) =>
                {
                    FontDialog fontDialog = new FontDialog();   
                    if (fontDialog.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
                        return;
                    FontFamilyBox.Text = fontDialog.Font.Name;
                    FontSizeBox.Text = fontDialog.Font.Size.ToString();
                };

                TextSizeBar.ValueChanged += (eventss, ee) =>
                {
                    TextSizeBox.Text = Convert.ToInt32(TextSizeBar.Value).ToString();
                };
                FindBackPictureBtn.Click += (eventss, ee) =>
                {
                    Microsoft.Win32.OpenFileDialog dialogICO = new Microsoft.Win32.OpenFileDialog();
                    dialogICO.Filter = "Pictures|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tif";
                    Nullable<bool> result = dialogICO.ShowDialog();
                    if (result == true)
                    {
                        BackPicturePathBox.Text = dialogICO.FileName;
                    }
                };
                OpacityTextBar.ValueChanged += (eventss, ee) =>
                {
                    OpacityTextBox.Text = Convert.ToInt32(OpacityTextBar.Value).ToString();
                };

                ShowCaptionBtn.Click += (eventss, ee) =>
                {
                    CaptionShow captionShow = new CaptionShow();

                    captionShow.Height = infoTease.SizeWindow.Height;
                    captionShow.Width = infoTease.SizeWindow.Width;

                    Caption.AlignmentText alignmentText = new Caption.AlignmentText();
                    if (TextSideBox.SelectedItem.ToString() == "Up") alignmentText = Caption.AlignmentText.Up;
                    if (TextSideBox.SelectedItem.ToString() == "Down") alignmentText = Caption.AlignmentText.Down;
                    if (TextSideBox.SelectedItem.ToString() == "Right") alignmentText = Caption.AlignmentText.Right;
                    if (TextSideBox.SelectedItem.ToString() == "Left") alignmentText = Caption.AlignmentText.Left;

                    Caption.Show(captionShow, PicturePathBox.Text, TextCaptionBox.Text, alignmentText, backColorTemp,
                        fontColorTemp, FontFamilyBox.Text, Convert.ToSingle(FontSizeBox.Text), (bool)BoldFontBox.IsChecked,
                        (bool)ItalicFontBox.IsChecked, Convert.ToSingle(TextSizeBox.Text) / 100, BackPicturePathBox.Text,
                        (bool)StretchedBPicBox.IsChecked, Convert.ToInt32(OpacityTextBox.Text));

                    captionShow.Show();
                };

                CreateCaptionBtn.Click += (eventss, ee) =>
                {

                    for (int i = 0; i < ListEventsBox.Items.Count; i++)
                    {
                        if (ListEventsBox.Items[i].ToString() == "Caption")
                        {
                            System.Windows.MessageBox.Show("There can only be one caption on the scene.");
                            return;
                        }
                    }
                    Caption.AlignmentText alignmentText = new Caption.AlignmentText();
                    if (TextSideBox.SelectedItem.ToString() == "Up") alignmentText = Caption.AlignmentText.Up;
                    if (TextSideBox.SelectedItem.ToString() == "Down") alignmentText = Caption.AlignmentText.Down;
                    if (TextSideBox.SelectedItem.ToString() == "Right") alignmentText = Caption.AlignmentText.Right;
                    if (TextSideBox.SelectedItem.ToString() == "Left") alignmentText = Caption.AlignmentText.Left;

                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    string ExtensionPicture; string PicturePath = "";
                    try
                    {
                        Bitmap tempp = new Bitmap(PicturePathBox.Text);
                        ExtensionPicture = System.IO.Path.GetExtension(PicturePathBox.Text);
                        PicturePath = numEvent + ExtensionPicture;
                        File.Copy(PicturePathBox.Text, path + @"\" + PicturePath);
                    }
                    catch { }
                    string BackPicturePathLine = "";
                    try
                    {
                        Bitmap tempp = new Bitmap(BackPicturePathBox.Text);
                        ExtensionPicture = System.IO.Path.GetExtension(BackPicturePathBox.Text);
                        BackPicturePathLine = numEvent + "w" + ExtensionPicture;
                        File.Copy(BackPicturePathBox.Text, path + @"\" + BackPicturePathLine);
                    }
                    catch { }

                    Caption caption = new Caption(
                        PicturePath,
                        TextCaptionBox.Text,
                        alignmentText,
                        backColorTemp.ToArgb(),
                        fontColorTemp.ToArgb(),
                        FontFamilyBox.Text,
                        Convert.ToSingle(FontSizeBox.Text),
                        (bool)BoldFontBox.IsChecked,
                        (bool)ItalicFontBox.IsChecked,
                        Convert.ToSingle(TextSizeBox.Text) / 100,
                        BackPicturePathLine,
                        (bool)StretchedBPicBox.IsChecked,
                        Convert.ToInt32(OpacityTextBox.Text));

                    using (FileStream fs = new FileStream(path + @"\" + numEvent.ToString() + ".json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, caption);
                    }
                    ListEventsBox.Items.Add("Caption");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "Caption";
                    else evFile = evFile + "\nCaption";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                #region MessageBox

                string[] iconMessageList = { "None", "Asterisk", "Error", "Exclamation", "Hand", "Information", "Question", "Stop", "Warning" };
                foreach (string item in iconMessageList) IconMessageBox.Items.Add(item);

                ShowMessageBtn.Click += (eventss, ee) =>
                {

                    MessageBoxImage messageBoxImage = new MessageBoxImage();
                    if (IconMessageBox.SelectedIndex == 0) messageBoxImage = MessageBoxImage.None;
                    if (IconMessageBox.SelectedIndex == 1) messageBoxImage = MessageBoxImage.Asterisk;
                    if (IconMessageBox.SelectedIndex == 2) messageBoxImage = MessageBoxImage.Error;
                    if (IconMessageBox.SelectedIndex == 3) messageBoxImage = MessageBoxImage.Exclamation;
                    if (IconMessageBox.SelectedIndex == 4) messageBoxImage = MessageBoxImage.Hand;
                    if (IconMessageBox.SelectedIndex == 5) messageBoxImage = MessageBoxImage.Information;
                    if (IconMessageBox.SelectedIndex == 6) messageBoxImage = MessageBoxImage.Question;
                    if (IconMessageBox.SelectedIndex == 7) messageBoxImage = MessageBoxImage.Stop;
                    if (IconMessageBox.SelectedIndex == 8) messageBoxImage = MessageBoxImage.Warning;

                    MessageEvent.Show(TextMessageBox.Text, SenderMessageBox.Text, messageBoxImage);
                };

                CreateMessageBtn.Click += (eventss, ee) =>
                {
                    MessageBoxImage messageBoxImage = new MessageBoxImage();
                    if (IconMessageBox.SelectedIndex == 0) messageBoxImage = MessageBoxImage.None;
                    if (IconMessageBox.SelectedIndex == 1) messageBoxImage = MessageBoxImage.Asterisk;
                    if (IconMessageBox.SelectedIndex == 2) messageBoxImage = MessageBoxImage.Error;
                    if (IconMessageBox.SelectedIndex == 3) messageBoxImage = MessageBoxImage.Exclamation;
                    if (IconMessageBox.SelectedIndex == 4) messageBoxImage = MessageBoxImage.Hand;
                    if (IconMessageBox.SelectedIndex == 5) messageBoxImage = MessageBoxImage.Information;
                    if (IconMessageBox.SelectedIndex == 6) messageBoxImage = MessageBoxImage.Question;
                    if (IconMessageBox.SelectedIndex == 7) messageBoxImage = MessageBoxImage.Stop;
                    if (IconMessageBox.SelectedIndex == 8) messageBoxImage = MessageBoxImage.Warning;

                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    MessageEvent messageEvent = new MessageEvent(TextMessageBox.Text, SenderMessageBox.Text, messageBoxImage);

                    using (FileStream fs = new FileStream(path + @"\" + numEvent.ToString() + ".json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, messageEvent);
                    }
                    ListEventsBox.Items.Add("MessageBox");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "MessageBox";
                    else evFile = evFile + "\nMessageBox";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                #region Visible Window

                CreateChangeOpacityBtn.Click += (eventss, ee) =>
                {
                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    VisibleWindow visibleWindow = new VisibleWindow((bool)VisibleWindowBox.IsChecked);

                    using (FileStream fs = new FileStream(path + @"\" + numEvent.ToString() + ".json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, visibleWindow);
                    }
                    ListEventsBox.Items.Add("VisibleWindow");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "VisibleWindow";
                    else evFile = evFile + "\nVisibleWindow";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                #region Change wallpaper

                string[] allStyles = { "Stretched", "Centered", "Tiled", "Filled", "Fited", "Span" };
                foreach (string item in allStyles)  StyleWallpaperBox.Items.Add(item);

                FindPictureWallpaperBtn.Click += (eventss, ee) =>
                {
                    Microsoft.Win32.OpenFileDialog dialogICO = new Microsoft.Win32.OpenFileDialog();
                    dialogICO.Filter = "Pictures|*.bmp;*.jpg;*.jpeg;*.png;*.gif;*.tif";
                    Nullable<bool> result = dialogICO.ShowDialog();
                    if (result == true)
                    {
                        PictureWallpaperPathBox.Text = dialogICO.FileName;
                    }
                };

                CreateChangeWallpaperBtn.Click += (eventss, ee) =>
                {

                    Wallpaper.Style alignmentText = new Wallpaper.Style();
                    if (StyleWallpaperBox.SelectedIndex == 0) alignmentText = Wallpaper.Style.Stretched;
                    if (StyleWallpaperBox.SelectedIndex == 1) alignmentText = Wallpaper.Style.Centered;
                    if (StyleWallpaperBox.SelectedIndex == 2) alignmentText = Wallpaper.Style.Tiled;
                    if (StyleWallpaperBox.SelectedIndex == 3) alignmentText = Wallpaper.Style.Filled;
                    if (StyleWallpaperBox.SelectedIndex == 4) alignmentText = Wallpaper.Style.Fited;
                    if (StyleWallpaperBox.SelectedIndex == 5) alignmentText = Wallpaper.Style.Span;

                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    string ExtensionPicture; string PicturePath = "";
                    try
                    {
                        Bitmap tempp = new Bitmap(PictureWallpaperPathBox.Text);
                        ExtensionPicture = System.IO.Path.GetExtension(PictureWallpaperPathBox.Text);
                        PicturePath = numEvent + "wallpaper" + ExtensionPicture;
                        File.Copy(PictureWallpaperPathBox.Text, path + @"\" + PicturePath);
                    }
                    catch
                    {
                        System.Windows.MessageBox.Show("The picture is not working.");
                        return;
                    }

                    Wallpaper changeOpacity = new Wallpaper(PicturePath, alignmentText);

                    using (FileStream fs = new FileStream(path + @"\" + numEvent.ToString() + ".json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, changeOpacity);
                    }
                    ListEventsBox.Items.Add("ChangeWallpaper");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "ChangeWallpaper";
                    else evFile = evFile + "\nChangeWallpaper";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                #region Open link

                ShowLinkBtn.Click += (eventss, ee) =>
                {
                    OpenLink.Open(LinkPathBox.Text);
                };
                CreateLinkBtn.Click += (eventss, ee) =>
                {
                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    OpenLink openLink = new OpenLink(LinkPathBox.Text);

                    using (FileStream fs = new FileStream(path + @"\" + numEvent.ToString() + ".json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, openLink);
                    }
                    ListEventsBox.Items.Add("OpenLink");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "OpenLink";
                    else evFile = evFile + "\nOpenLink";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                #region Time delay

                IntervalBar.ValueChanged += (eventss, ee) =>
                {
                    IntervalBox.Text = Convert.ToInt32(IntervalBar.Value).ToString();
                };

                CreateTimeDelayBtn.Click += (eventss, ee) =>
                {
                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    TimeDelay timeDelay = new TimeDelay(Convert.ToInt32(IntervalBox.Text));

                    using (FileStream fs = new FileStream(path + @"\" + numEvent.ToString() + ".json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, timeDelay);
                    }
                    ListEventsBox.Items.Add("TimeDelay");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "TimeDelay";
                    else evFile = evFile + "\nTimeDelay";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                #region Next scene

                CreateNextSceneBtn.Click += (eventss, ee) =>
                {
                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    ListEventsBox.Items.Add("NextScene");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "NextScene";
                    else evFile = evFile + "\nNextScene";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                #region Change size window

                CreateChangeSizeWindowBtn.Click += (eventss, ee) =>
                {
                    if (!int.TryParse(ChangeWidthWindowBox.Text, out temp) || temp < 500 || temp > 2000)
                    {
                        System.Windows.MessageBox.Show("The window width should not be less than 500 and more than 2000 pixels.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    if (!int.TryParse(ChangeHeightWindowBox.Text, out temp) || temp < 500 || temp > 2000)
                    {
                        System.Windows.MessageBox.Show("The window height should not be less than 500 and more than 2000 pixels.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    int numEvent = ListEventsBox.Items.Count + 1;
                    string path = @"Export\" + infoTease.NameFolder + @"\" + infoTease.NameFolder + @"\" + ListScenesBox.SelectedItem.ToString();

                    ChangeSizeWindow changeSizeWindow = new ChangeSizeWindow(Convert.ToInt32(ChangeWidthWindowBox.Text), Convert.ToInt32(ChangeHeightWindowBox.Text));

                    using (FileStream fs = new FileStream(path + @"\" + numEvent.ToString() + ".json", FileMode.Create))
                    {
                        JsonSerializer.Serialize(fs, changeSizeWindow);
                    }
                    ListEventsBox.Items.Add("ChangeSizeWindow");
                    if (!File.Exists(path + @"\ev.txt"))
                    {
                        using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                        {
                        }
                    }
                    string evFile = "";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Open))
                    {
                        byte[] buffer = new byte[fstream.Length];
                        fstream.Read(buffer, 0, buffer.Length);
                        evFile = Encoding.Default.GetString(buffer);
                    }
                    if (evFile == "") evFile = evFile + "ChangeSizeWindow";
                    else evFile = evFile + "\nChangeSizeWindow";
                    using (FileStream fstream = new FileStream(path + @"\ev.txt", FileMode.Create))
                    {
                        byte[] buffer = Encoding.Default.GetBytes(evFile);
                        fstream.Write(buffer, 0, buffer.Length);
                    }
                };

                #endregion

                TB.SelectedIndex = 1;
            };
        }

        private void ListEventsBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ListEventsBox.SelectedIndex = -1;
        }
    }
}
