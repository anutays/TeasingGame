﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeasingGame_Maker
{
    internal class OpenLink
    {
        public string Link { get; set; }
        public OpenLink(string link)
        {
            Link = link;
        }
        public static void Open(string link)
        {
            try
            {
                Process.Start(new ProcessStartInfo(link) { UseShellExecute = true });
            }
            catch
            {
                try
                {
                    Process.Start(new ProcessStartInfo("www." + link) { UseShellExecute = true });
                }
                catch
                {
                    System.Windows.MessageBox.Show("Cannot open a non-existent link");
                }
            }

        }
    }
}
