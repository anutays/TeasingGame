﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.Json;
using System.Threading;
using System.Windows.Forms;

namespace TeasingGame
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        InfoTease infoTease = new InfoTease();
        int Page = 0;
        int MaxPage = 0;
        int Event = 1;
        int MaxEvents = 1;
        string[] EventsInFile;
        string MainFolder = "events";
        bool[] PagesCompleted;
        string CurrentPageFolder = "";
        bool CaptionOnPage = false;
        Caption caption;
        MessageEvent message;
        VisibleWindow visibleWindow;
        Wallpaper wallpaper;
        OpenLink openLink;
        TimeDelay timeDelay;
        ChangeSizeWindow changeSizeWindow;
        public MainWindow()
        {
            InitializeComponent();
            if (!File.Exists("info.json"))
            {
                System.Windows.MessageBox.Show("File info.json don't exist.");
                Environment.Exit(0);
            }
            using (FileStream fs = new FileStream("info.json", FileMode.Open))
            {
                infoTease = JsonSerializer.Deserialize<InfoTease>(fs);
            }
            MainFolder = infoTease.NameFolder;
            if (!Directory.Exists(MainFolder))
            {
                System.Windows.MessageBox.Show($"Folder {MainFolder} don't exist.");
                Environment.Exit(0);
            }
            MaxPage = Directory.GetDirectories(MainFolder).Length;
            if (MaxPage == 0)
            {
                System.Windows.MessageBox.Show("There are no events");
                Environment.Exit(0);
            }
            for (int i = 1; i <= MaxPage; i++)
            {
                if (!Directory.Exists(MainFolder + @"\" + i))
                {
                    System.Windows.MessageBox.Show($"Incorrect folder location in {MainFolder} folder");
                    Environment.Exit(0);
                }
            }
            PagesCompleted = new bool[MaxPage];
            for (int i = 0; i < MaxPage; i++) PagesCompleted[i] = false;
            this.Width = infoTease.SizeWindow.Width;
            this.Height = infoTease.SizeWindow.Height;
            this.Title = infoTease.Name;
            if (infoTease.Opacity == 1) this.Visibility = Visibility.Visible;
            else this.Visibility = Visibility.Hidden;

            try
            {
                Form form = new Form();
                form.Icon = new Icon(infoTease.IconWindow);
                this.Icon = new BitmapImage(new Uri(infoTease.IconWindow, UriKind.Relative));
            }
            catch { }

            Page += 1;

            this.MouseDown += NextSceneClick;

            timer.Interval = 10;
            timer.Tick += MainTimer_Tick;
            timer.Enabled = true;

        }

        private void NextSceneClick(object sender, MouseButtonEventArgs e)
        {
            Page++;
            CaptionOnPage = false;
        }

        private async void MainTimer_Tick(object sender, EventArgs e)
        {
            timer.Enabled = false;

            if (Page > MaxPage) Environment.Exit(0);
            CurrentPageFolder = MainFolder + @"\" + Page.ToString();
            try
            {
                using (FileStream fs = new FileStream(CurrentPageFolder + @"\ev.txt", FileMode.Open))
                {
                    byte[] buffer = new byte[fs.Length];
                    fs.Read(buffer, 0, buffer.Length);
                    string textFromFile = Encoding.Default.GetString(buffer);
                    EventsInFile = textFromFile.Split('\n');
                }
            }
            catch
            {
                System.Windows.MessageBox.Show("The files are corrupted or the program is already running.");
                Environment.Exit(0);
            }

            Event = 1;
            MaxEvents = EventsInFile.Length;


            if (PagesCompleted[Page - 1] == false)
            {
                for (Event = 1; Event <= MaxEvents; Event++)
                {
                    //System.Windows.MessageBox.Show(EventsInFile[Event - 1]);
                    if (EventsInFile[Event - 1] == "Caption" || EventsInFile[Event - 1] == "Caption\r")
                    {
                        CaptionOnPage = true;
                        using (FileStream fs = new FileStream(CurrentPageFolder + @"\" + Event + ".json", FileMode.Open))
                        {
                            caption = JsonSerializer.Deserialize<Caption>(fs);
                        }
                        Caption.Show(this, CurrentPageFolder + @"\" + caption.Picture, caption.Text, caption.Alignment,
                            System.Drawing.Color.FromArgb(caption.BgColor), System.Drawing.Color.FromArgb(caption.FontColor), caption.FontFamily,
                            caption.FontSize, caption.BoldFont, caption.ItalicFont, caption.TextSize, CurrentPageFolder + @"\" + caption.BackPicture,
                            caption.StretchedBackPicture, caption.OpacityFont); 
                    }
                    if (EventsInFile[Event - 1] == "MessageBox" || EventsInFile[Event - 1] == "MessageBox\r")
                    {
                        using (FileStream fs = new FileStream(CurrentPageFolder + @"\" + Event + ".json", FileMode.Open))
                        {
                            message = JsonSerializer.Deserialize<MessageEvent>(fs);
                        }
                        MessageEvent.Show(message.Text, message.Sender, message.Icon);
                    }
                    if (EventsInFile[Event - 1] == "VisibleWindow" || EventsInFile[Event - 1] == "VisibleWindow\r")
                    {
                        using (FileStream fs = new FileStream(CurrentPageFolder + @"\" + Event + ".json", FileMode.Open))
                        {
                            visibleWindow = JsonSerializer.Deserialize<VisibleWindow>(fs);
                        }
                        if (visibleWindow.Vis) this.Visibility = Visibility.Visible;
                        else this.Visibility = Visibility.Hidden;

                    }
                    if (EventsInFile[Event - 1] == "ChangeWallpaper" || EventsInFile[Event - 1] == "ChangeWallpaper\r")
                    {
                        using (FileStream fs = new FileStream(CurrentPageFolder + @"\" + Event + ".json", FileMode.Open))
                        {
                            wallpaper = JsonSerializer.Deserialize<Wallpaper>(fs);
                        }
                        Wallpaper.Set(CurrentPageFolder + @"\" + wallpaper.Image, wallpaper.StyleImage);
                    }
                    if (EventsInFile[Event - 1] == "OpenLink" || EventsInFile[Event - 1] == "OpenLink\r")
                    {
                        using (FileStream fs = new FileStream(CurrentPageFolder + @"\" + Event + ".json", FileMode.Open))
                        {
                            openLink = JsonSerializer.Deserialize<OpenLink>(fs);
                        }
                        OpenLink.Open(openLink.Link);
                    }
                    if (EventsInFile[Event - 1] == "TimeDelay" || EventsInFile[Event - 1] == "TimeDelay\r")
                    {
                        using (FileStream fs = new FileStream(CurrentPageFolder + @"\" + Event + ".json", FileMode.Open))
                        {
                            timeDelay = JsonSerializer.Deserialize<TimeDelay>(fs);
                        }
                        this.MouseDown -= NextSceneClick;
                        await TimeDelay.Run(timeDelay.Interval);
                        this.MouseDown += NextSceneClick;
                    }
                    if (EventsInFile[Event - 1] == "NextScene" || EventsInFile[Event - 1] == "NextScene\r")
                    {
                        Page++;
                        CaptionOnPage = false;
                        timer.Enabled = true;
                        return;
                    }
                    if (EventsInFile[Event - 1] == "ChangeSizeWindow" || EventsInFile[Event - 1] == "ChangeSizeWindow\r")
                    {
                        using (FileStream fs = new FileStream(CurrentPageFolder + @"\" + Event + ".json", FileMode.Open))
                        {
                            changeSizeWindow = JsonSerializer.Deserialize<ChangeSizeWindow>(fs);
                        }
                        this.Width = changeSizeWindow.Width;
                        this.Height = changeSizeWindow.Height;

                        double screenHeight = SystemParameters.FullPrimaryScreenHeight;
                        double screenWidth = SystemParameters.FullPrimaryScreenWidth;

                        this.Top = (screenHeight - this.Height) / 0x00000002;
                        this.Left = (screenWidth - this.Width) / 0x00000002;

                    }
                }
                PagesCompleted[Page - 1] = true;

            }

            if (!CaptionOnPage)
            {
                Page++;
            }
            //if (!deleteComponents)
            //{
            //    for (int i = this.Controls.Count; i >= 1; i--)
            //    {
            //        this.Controls.RemoveAt(i - 1);
            //        CaptionOnPage = false;
            //    }
            //    deleteComponents = true;
            //}



            timer.Enabled = true;
        }

    }
}
