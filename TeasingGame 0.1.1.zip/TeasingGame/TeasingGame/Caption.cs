﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows;
using System.Drawing;

namespace TeasingGame
{
    internal class Caption
    {
        public string Picture { get; set; }
        public string Text { get; set; }
        public AlignmentText Alignment { get; set; }
        public int BgColor { get; set; }
        public int FontColor { get; set; }
        public string FontFamily { get; set; }
        public float FontSize { get; set; }
        public bool BoldFont { get; set; }
        public bool ItalicFont { get; set; }
        public float TextSize { get; set; }
        public string BackPicture { get; set; }
        public bool StretchedBackPicture { get; set; }
        public int OpacityFont { get; set; }
        public Caption(string picture, string text, AlignmentText alignment, int bgColor, int fontColor,
            string fontFamily, float fontSize, bool boldFont, bool italicFont, float textSize, string backPicture,
            bool stretchedBackPicture, int opacityFont)
        {
            Picture = picture; Text = text; Alignment = alignment; BgColor = bgColor;
            FontColor = fontColor; FontFamily = fontFamily; FontSize = fontSize; BoldFont = boldFont; ItalicFont = italicFont;
            TextSize = textSize; BackPicture = backPicture; StretchedBackPicture = stretchedBackPicture;
            OpacityFont = opacityFont;
        }

        static public void Show(MainWindow form, string picture, string text, AlignmentText alignment, System.Drawing.Color bgColor,
            System.Drawing.Color fontColor, string fontFamily, float fontSize, bool boldFont, bool italicFont, float textSize, string backPicture,
            bool stretchedBackPicture, int opacityFont)
        {
            bool enableBackPicture = true;
            try
            {
                Bitmap temp = new Bitmap(backPicture);
            }
            catch
            {
                enableBackPicture = false;
            }
            bool enablePicture = true;
            try
            {
                Bitmap temp = new Bitmap(picture);
            }
            catch
            {
                enablePicture = false;
            }
            form.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(bgColor.A,
                        bgColor.R, bgColor.G, bgColor.B));
            if (enableBackPicture)
            {
                ImageBrush BackgroundBrush = new ImageBrush();
                BackgroundBrush.ImageSource = new BitmapImage(new Uri(backPicture, UriKind.Relative));

                if (stretchedBackPicture) BackgroundBrush.Stretch = Stretch.Fill;
                else BackgroundBrush.Stretch = Stretch.Uniform;
                form.BackPictureGrid.Background = BackgroundBrush;
            }
            form.TextLabel.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb((byte)opacityFont,
                        fontColor.R, fontColor.G, fontColor.B));
            form.TextLabel.Content = text;
            form.TextLabel.FontSize = fontSize;
            form.TextLabel.FontFamily = new System.Windows.Media.FontFamily(fontFamily);
            if (boldFont) form.TextLabel.FontWeight = FontWeights.Bold;
            if (italicFont) form.TextLabel.FontStyle = FontStyles.Italic;

            if (enablePicture)
            {
                ImageBrush PictureBrush = new ImageBrush();
                PictureBrush.ImageSource = new BitmapImage(new Uri(picture, UriKind.Relative));
                PictureBrush.Stretch = Stretch.Uniform;
                form.PictureCaption.Background = PictureBrush;
            }
            Grid.SetRow(form.TextLabel, 0);
            Grid.SetColumn(form.TextLabel, 0);
            Grid.SetRow(form.PictureCaption, 0);
            Grid.SetColumn(form.PictureCaption, 0);

            Grid.SetColumnSpan(form.PictureCaption, 1);
            Grid.SetColumnSpan(form.TextLabel, 1);
            Grid.SetRowSpan(form.PictureCaption, 1);
            Grid.SetRowSpan(form.TextLabel, 1);

            form.row1.Height = new GridLength(1, GridUnitType.Star);
            form.row2.Height = new GridLength(1, GridUnitType.Star);
            form.col1.Width = new GridLength(1, GridUnitType.Star);
            form.col2.Width = new GridLength(1, GridUnitType.Star);

            if (alignment == AlignmentText.Up)
            {
                Grid.SetRow(form.TextLabel, 0);
                Grid.SetColumn(form.TextLabel, 0);
                Grid.SetRow(form.PictureCaption, 1);
                Grid.SetColumn(form.PictureCaption, 0);

                Grid.SetColumnSpan(form.TextLabel, 2);
                Grid.SetColumnSpan(form.PictureCaption, 2);

                form.row1.Height = new GridLength(form.Height * textSize, GridUnitType.Pixel);
            }
            if (alignment == AlignmentText.Down)
            {
                Grid.SetRow(form.TextLabel, 1);
                Grid.SetColumn(form.TextLabel, 0);
                Grid.SetRow(form.PictureCaption, 0);
                Grid.SetColumn(form.PictureCaption, 0);

                Grid.SetColumnSpan(form.TextLabel, 2);
                Grid.SetColumnSpan(form.PictureCaption, 2);

                form.row2.Height = new GridLength(form.Height * textSize, GridUnitType.Pixel);
            }
            if (alignment == AlignmentText.Right)
            {
                Grid.SetRow(form.TextLabel, 0);
                Grid.SetColumn(form.TextLabel, 1);
                Grid.SetRow(form.PictureCaption, 0);
                Grid.SetColumn(form.PictureCaption, 0);

                Grid.SetRowSpan(form.TextLabel, 2);
                Grid.SetRowSpan(form.PictureCaption, 2);

                form.col2.Width = new GridLength(form.Width * textSize, GridUnitType.Pixel);
            }
            if (alignment == AlignmentText.Left)
            {
                Grid.SetRow(form.TextLabel, 0);
                Grid.SetColumn(form.TextLabel, 0);
                Grid.SetRow(form.PictureCaption, 0);
                Grid.SetColumn(form.PictureCaption, 1);

                Grid.SetRowSpan(form.TextLabel, 2);
                Grid.SetRowSpan(form.PictureCaption, 2);

                form.col1.Width = new GridLength(form.Width * textSize, GridUnitType.Pixel);
            }

            //while (label.Width < System.Windows.Forms.TextRenderer.MeasureText(label.Text,
            // new Font(label.Font.FontFamily, label.Font.Size, label.Font.Style)).Width)
            //{
            //    label.Font = new Font(label.Font.FontFamily, label.Font.Size - 0.01f, label.Font.Style);
            //}
            //form.Controls.Add(label);
            //form.Controls.Add(pictureBox);
        }
        public enum AlignmentText
        {
            Up, Down, Left, Right
        }

    }
}
