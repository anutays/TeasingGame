﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace TeasingGame
{
    internal class MessageEvent
    {
        public string Text { get; set; }
        public string Sender { get; set; }
        public MessageBoxImage Icon { get; set; }
        public MessageEvent(string text, string sender, MessageBoxImage icon)
        {
            Text = text; Sender = sender; Icon = icon;
        }
        static public void Show(string text, string sender, MessageBoxImage icon)
        {
            System.Windows.MessageBox.Show(text, sender, MessageBoxButton.OK, icon);
        }
    }
}
